<?php 


class Authentification
{
	function __construct()
	{
		
	}
	
	function authentification($page)
	{
		session_start();


		if(!isset($_SESSION['LOGIN']) ){
			
			if (!isset($_SERVER['PHP_AUTH_USER']) ) {
				header('WWW-Authenticate: Basic realm="My Realm"');
				header('HTTP/1.0 401 Unauthorized');
			}else if($this->verifierUserPass($_SERVER['PHP_AUTH_USER'],$_SERVER['PHP_AUTH_PW'])) {
				$_SESSION['LOGIN']='ok';
				header("Location: ".$page);	
			}else{
				header('WWW-Authenticate: Basic realm="My Realm"');
				header('HTTP/1.0 401 Unauthorized');
			}
			
		}else if($_SESSION['LOGIN']=='ko'){
			header('WWW-Authenticate: Basic realm="My Realm"');
			header('HTTP/1.0 401 Unauthorized');
			$_SESSION['LOGIN']='CON';

		}else if($_SESSION['LOGIN']=='CON'){

			if($this->verifierUserPass($_SERVER['PHP_AUTH_USER'],$_SERVER['PHP_AUTH_PW'])) {
				$_SESSION['LOGIN']='ok';
				header("Location: ".$page);	
			}else {
				header('WWW-Authenticate: Basic realm="My Realm"');
				header('HTTP/1.0 401 Unauthorized');
				$_SESSION['LOGIN']='ko';
			}

		}else{
			header('WWW-Authenticate: Basic realm="My Realm"');
			header('HTTP/1.0 401 Unauthorized');
			$_SESSION['LOGIN']='ko';
		}
	}






	function verifier()
	{
		session_start();
		$isConnected=false;

		if(isset($_SESSION['LOGIN']) && $_SESSION['LOGIN']=='ok'){
			$isConnected=true;
		}else{
			$isConnected=false;
		}

		return $isConnected;
	}


	function verifierUserPass($login,$pass)
	{
		$db=new BaseDonnee();
		return $db->verifierUserPass($login,$pass);
	}
}



class BaseDonnee
{

	
	private $mysqli;

	function __construct()
	{
		$this->mysqli = new mysqli("localhost", "root", "root", "boutique");
		if ($this->mysqli->connect_errno) {
			echo "Echec lors de la connexion à MySQL : (" . $this->mysqli->connect_errno . ") " . $this->mysqli->connect_error;
		}
	}

	function getAllProduit(){
		$listDesProduit=array();
		$res = $this->mysqli->query("SELECT * FROM produit ");

		if ( $res === FALSE ) { 
			echo 'ss';
		}else{
			for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {

				$res->data_seek($row_no);
				$row = $res->fetch_assoc();

				$produit =  new Produit();

				$produit->id=$row['id'];
				$produit->nom=$row['nom'];
				$produit->description=$row['description'];
				$produit->image=$row['image'];
				$produit->quantite=$row['quantite'];


				array_push($listDesProduit,$produit);

			}	
		}
		return $listDesProduit;
		

	}



function rechrche($produitNom){
		$listDesProduit=array();
		$res = $this->mysqli->query("SELECT * FROM produit where nom like '".$produitNom."%'");
        if ( $res === FALSE ) { 
			echo "SELECT * FROM produit where nom like '".$produitNom."'";
			echo "Error: "  . "<br>" . $this->mysqli->error;
		}else{
			for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {

				$res->data_seek($row_no);
				$row = $res->fetch_assoc();

				$produit =  new Produit();

				$produit->id=$row['id'];
				$produit->nom=$row['nom'];
				$produit->description=$row['description'];
				$produit->image=$row['image'];
				$produit->quantite=$row['quantite'];


				array_push($listDesProduit,$produit);

			}	
		}
		return $listDesProduit;
		

	}



	function rechrcheid($id){
		$listDesProduit=array();
		$res = $this->mysqli->query("SELECT * FROM produit where id = ".$id);

		if ( $res === FALSE ) { 
			echo "SELECT * FROM produit where id = ".$id;
			echo "Error: "  . "<br>" . $this->mysqli->error;
		}else{
			for ($row_no = $res->num_rows - 1; $row_no >= 0; $row_no--) {

				$res->data_seek($row_no);
				$row = $res->fetch_assoc();

				$produit =  new Produit();

				$produit->id=$row['id'];
				$produit->nom=$row['nom'];
				$produit->description=$row['description'];
				$produit->image=$row['image'];
				$produit->quantite=$row['quantite'];


				array_push($listDesProduit,$produit);

			}	
		}
		return $listDesProduit;
		

	}


	function verifierUserPass($login,$pass){
		
       //echo "SELECT * FROM utilisateur where login like '".$login."' and pass like '".$pass."' ";

		$res = $this->mysqli->query("SELECT * FROM utilisateur where login like '".$login."' and pass like '".$pass."' ");
		
		if ( $res === FALSE ) {
			return false;
		}else{
			if($res->num_rows==0){
				return false;
			}else{
				return true;
			}

		}

	}


	function insertProduit($nom,$description,$quantite){
		$sql = "INSERT INTO `produit`( `nom`, `description`, `image`, `quantite`) VALUES ('".$nom."','".$description."','',".$quantite.")";
        
		if ($this->mysqli->query($sql) === TRUE) {
			echo "Produit Ajouter avec success";
		} else {
			echo "Error: " . $sql . "<br>" . $this->mysqli->error;
		}

	}

}
?>