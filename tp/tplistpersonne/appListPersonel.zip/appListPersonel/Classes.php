<?php 
class Utilisateur
{
     public $id;
     public $nom;
     public $prenom;
     public $login;
     public $pass;
     public $profil;
}

class Produit
{
     public $id;
     public $nom;
     public $description;
     public $quantite;
     public $image;
}

?>