<?php
	require_once('BaseDonnee.php');
if($_GET){
    if(isset($_GET['desconnexion'])){
        desconnexion();
    }elseif(isset($_GET['connexion'])){
        connexion();
    }
}

    function desconnexion()
    {
      session_start();
      $_SESSION['LOGIN']='ko';
      header("Location:index.php");
	}
	
    function connexion()
    {
       $auth=new Authentification();
       $auth->authentification("index.php");
    }





?>