
<?php
require_once('BaseDonnee.php');

$auth=new Authentification();
$isConnected=$auth->verifier();

if(!$isConnected){
	header('Location: index.php');  
}


function insert($nom,$description,$quantite)
{
	$db=new BaseDonnee();
	$db->insertProduit($nom,$description,$quantite);
}

if($_GET){
	if(isset($_GET['insert'])){
		insert($_GET['nom'],$_GET['description'],$_GET['quantite']);
	}
	if(isset($_GET['annuler'])){
		header('Location: index.php');  
	}
}

?>

<html>
<body>
<center>
<h2 style="padding-bottom: 20;">Ajouter un produit</h2>
	<form action="formulaire.php">
		<div style="padding-bottom: 15;">Nom&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="nom" /></div>
		<div style="padding-bottom: 15;">Déscription&nbsp&nbsp&nbsp<input type="text" name="description" /></div>
		<div style="padding-bottom: 15;">Quantite&nbsp<input type="text" name="quantite" /></div>
		<input type="submit" name="insert" value="Ajouter" />
		<input type="submit" name="annuler" value="Annler" />
	</form>
 </center>
</body>
<scrip>
	function annuler(p1, p2) {
    window.location.href = 'index.php';
 }
	
</script>
</html>


