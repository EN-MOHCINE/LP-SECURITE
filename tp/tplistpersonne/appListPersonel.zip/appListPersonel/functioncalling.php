<?php
if($_GET){
    if(isset($_GET['insert'])){
        insert($_GET['txt']);
    }elseif(isset($_GET['select'])){
        select($_GET['txt']);
    }
}

    function select($tes)
    {
       echo "The select function is called.".$tes;
    }
    function insert()
    {
       echo "The insert function is called.";
    }

?>