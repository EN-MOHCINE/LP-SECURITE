<?php 

	require_once('BaseDonnee.php');
	require_once('Classes.php');
	$db=new BaseDonnee();

	$auth=new Authentification();
	$isConnected=$auth->verifier();
	
	if($_GET){
		if(isset($_GET['rechrche'])){
			$_REQUEST['listProduit'] =	$db->rechrche($_GET['rechrcheText']);

		}else if(isset($_GET['id'])){
			$_REQUEST['listProduit'] =	$db->rechrcheid($_GET['id']);

		}else{
			$_REQUEST['listProduit'] = $db->getAllProduit();

	}
	}else{
			$_REQUEST['listProduit'] = $db->getAllProduit();
	}

?>

<!DOCTYPE html>
<html>

<header>
	<link rel="stylesheet" type="text/css" media="screen" href="/produit.css">
</header>
<body>

	<center>
		<table style="width:60%">
			<tr>
				<td><h3>List des produit</h3></td>
				<td><form action="authentification.php">

					<?php 
				    if($isConnected){
						echo '<a href="formulaire.php">Ajouter un produit</a>&nbsp&nbsp&nbsp<input type="submit" name="desconnexion" value="desconnexion" />';
					}else{
						echo '<input type="submit" name="connexion" value="connexion" />';
					}

					?>

				</form>
			</td>		
		</tr>
	</table>


	<div><form action="index.php">
		<div><input type="text" name="rechrcheText" />
			<input type="submit" name="rechrche" value="rechrche" />
		</div>
	</form></div>

	<table style="width:60%" border="1">
		<tr>
			<td>Produit</td>
			<td>D�scription</td>		
			<td>Quantite</td>
		</tr>

		<?php 

		$listProduit  =$_REQUEST['listProduit'];
	
	foreach ($listProduit as $produit){

			echo "<tr>";
			echo "<td>".$produit->nom."</td>";
			echo "<td>".$produit->description."</td>";
			echo "<td>".$produit->quantite."</td>";
			echo "</tr>";

			}
	?>
	</table>
</center>
</body>
</html>